library(MASS)
library(glmnet)
check<-read.csv("no_more_datahandling.csv",header=T)

total<-read.csv("nomore_total.csv",header=T)
via0_data<-read.csv("nomore_via0.csv",header=T)
via1_data<-read.csv("nomore_via1.csv",header=T)
via2_data<-read.csv("nomore_via2.csv",header=T)
via3_data<-read.csv("nomore_via3.csv",header=T)


getwd()




total$Year<-as.factor(total$Year)
total$Month<-as.factor(total$Month)
total$Date_num<-as.factor(total$Date_num)
total$popular<-as.factor(total$popular)
total$FirstFlightDep_hr_f<-as.factor(as.character(total$FirstFlightDep_hr_f))

names(total)

total<-subset(total,subset=is.na(BookingPrice1)!=T,select=c(Year,Month,Date_num,Date_left,destination,viaNum,
                             FirstFlightDep_hr_f,rank2017_ver2,popular,BookingAgency1,
                             StayTime_TOTAL,MovingTime_TOTAL,BookingPrice1))

set.seed(2018)
summary(na.omit(total))
n<-nrow(total)
str(total)
index<-sample(1:n,0.71*n,replace=F)
train<-total[index,]
test<-total[-index,]
tr.x<-model.matrix(BookingPrice1~.,data=train)[,-1]
tr.y=train$BookingPrice1
te.x<-model.matrix(BookingPrice1~.,data=test)[,-1]
te.y=test$BookingPrice1

str(total)


fit.lasso<-glmnet(tr.x,tr.y,family="gaussian",alpha=1)
fit.ridge<-glmnet(tr.x,tr.y,family="gaussian",alpha=0)
fit.elnet<-glmnet(tr.x,tr.y,family="gaussian",alpha=0.5)

fit.lasso.cv<-cv.glmnet(tr.x,tr.y,type.measure = "mse",alpha=1,family="gaussian")
fit.ridge.cv<-cv.glmnet(tr.x,tr.y,type.measure = "mse",alpha=0,family="gaussian")
fit.elnet.cv<-cv.glmnet(tr.x,tr.y,type.measure = "mse",alpha=.5,family="gaussian")



for(i in 0:100) {
  assign(paste("fit", i, sep=""),cv.glmnet(tr.x,tr.y,type.measure = "mse",
                                           alpha=i/100,family="gaussian"))
}

par(mfrow=c(3,2))
plot(fit.lasso,xvar="lambda")
plot(fit10, main="LASSO")

plot(fit.ridge,xvar="lambda")
plot(fit0, main="Ridge")

plot(fit.elnet,xvar="lambda")
plot(fit5,main = "Elastic Net")



#MSE on test set
for(i in 0:100) {
  assign(paste("fit", i, sep=""),cv.glmnet(tr.x,tr.y,type.measure = "mse",
                                           alpha=i/100,family="gaussian"))
}


yhat0 <- predict(fit0, s=fit0$lambda.1se, newx=te.x)
yhat1 <- predict(fit1, s=fit1$lambda.1se, newx=te.x)
yhat2 <- predict(fit2, s=fit2$lambda.1se, newx=te.x)
yhat3 <- predict(fit3, s=fit3$lambda.1se, newx=te.x)
yhat4 <- predict(fit4, s=fit4$lambda.1se, newx=te.x)
yhat5 <- predict(fit5, s=fit5$lambda.1se, newx=te.x)
yhat6 <- predict(fit6, s=fit6$lambda.1se, newx=te.x)
yhat7 <- predict(fit7, s=fit7$lambda.1se, newx=te.x)
yhat8 <- predict(fit8, s=fit8$lambda.1se, newx=te.x)
yhat9 <- predict(fit9, s=fit9$lambda.1se, newx=te.x)
yhat10 <- predict(fit10, s=fit10$lambda.1se, newx=te.x)

rmse0 <- sqrt(mean((te.y - yhat0)^2))
rmse1 <- sqrt(mean((te.y - yhat1)^2))
rmse2 <- sqrt(mean((te.y - yhat2)^2))
rmse3 <- sqrt(mean((te.y - yhat3)^2))
rmse4 <- sqrt(mean((te.y - yhat4)^2))
rmse5 <- sqrt(mean((te.y - yhat5)^2))
rmse6 <- sqrt(mean((te.y - yhat6)^2))
rmse7 <- sqrt(mean((te.y - yhat7)^2))
rmse8 <- sqrt(mean((te.y - yhat8)^2))
rmse9 <- sqrt(mean((te.y - yhat9)^2))
rmse10 <- sqrt(mean((te.y - yhat10)^2))

test.y<-data.frame(te.y)
head(test.y)
library(dplyr)
names(test.y)
str(test.y)
test.y$te.y = as.numeric(test.y$te.y)
test.y$rmse = test.y$te.y - as.vector(test.y$yhat3)

test.y$yhat3<-yhat3
test.y$mse<-mean((test.y$te.y-test.y$yhat3)^2)


set.seed(2018)

##### Using built-in function 'lm' #####

# Fit a linear regression model.
fit = lm(formula=BookingPrice1 ~ Year+Date_num+destination+viaNum+
           StayTime_TOTAL+MovingTime_TOTAL, data=train)

summary(fit)

# beta hat (LSE)
fit$coef

Yhat = fit$fitted
Yhat = predict(fit)
train.RMSE = sqrt(mean((tr.y-Yhat)^2))
train.RMSE

Yhat0 = predict(fit,test)
test.RMSE = sqrt(mean((te.y-Yhat0)^2))
test.RMSE


install.packages("randomForest")
library(randomForest)
library(glmnet)
install.packages("tidyverse")
library(tidyverse)
install.packages("caret")
library(caret)


############ Method2 #############

######## Ridge #########
# Find the best lambda using cross-validation
# Cross-Validation�� ���� best lambda�� ã��!
cv <- cv.glmnet(tr.x, tr.y, alpha = 0)
# Display the best lambda value
cv$lambda.min

# Train Data�� ����~
model <- glmnet(tr.x, tr.y, alpha = 0, lambda = cv$lambda.min)
# coefficients
coef(model)


# Test Data�� ����~
library(dplyr)
library(Matrix)
predictions <- model %>% predict(te.x) %>% as.vector()
# RMSE, Rsquare
data.frame(
  RMSE = RMSE(predictions, test$BookingPrice1),
  Rsquare = R2(predictions, test$BookingPrice1)
)

######## LASSO #########

# Cross-Validation�� ���� best lambda�� ã��!
set.seed(2018) 
cv2 <- cv.glmnet(tr.x, tr.y, alpha = 1)
cv2$lambda.min

# Train Data�� ����~
model2 <- glmnet(tr.x, tr.y, alpha = 1, lambda = cv2$lambda.min)
# coefficients
coef(model2)

# Test Data�� ����~
predictions2 <- model2 %>% predict(te.x) %>% as.vector()
# RMSE, Rsquare
data.frame(
  RMSE = RMSE(predictions2, test$BookingPrice1),
  Rsquare = R2(predictions2, test$BookingPrice1)
)

######## Elsastic Net #########
# Train Data�� ����~
set.seed(2018)
model3 <- train(
  BookingPrice1 ~., data = train, method = "glmnet",
  trControl = trainControl("cv", number = 100),
  tuneLength = 100
)
# Best Tune�� ���� best lambda�� ã��!
model3$bestTune
coef(model3$finalModel, model3$bestTune$lambda)

# Test Data�� ����~
predictions <- model %>% predict(te.x)%>% as.vector()
# RMSE, Rsquare
data.frame(
  RMSE = RMSE(predictions, test$BookingPrice1),
  Rsquare = R2(predictions, test$BookingPrice1)
)

#################################################
############## Random Forest ####################
#################################################

library('ggplot2')
install.packages("ggthemes")
library('ggthemes') 
install.packages("scales")
library('scales')
library('randomForest') 
install.packages("gridExtra")
library('gridExtra')
install.packages("corrplot")
library('corrplot') 
install.packages("GGally")
library('GGally')
install.packages("e1071")
library('e1071')










