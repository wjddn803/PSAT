getwd()

setwd("C:/Users/Jungwoo Lim/Documents/2018�� ����/PSAT/�����/Data2")
library(stringr)

##########################################################
##################Data Handling ver2######################
##########################################################

change_data<-read.csv("TicketFinal_Ver2.csv", header=T)


##########�������� ����, �߰��غ���!##########
#splitDate
split_date<-str_split(change_data$Date,"-",n=3)
df<-data.frame(matrix(unlist(split_date),nrow=20576,byrow=T))
names(df)<-c("Year","Month","Date_num")
change_data2<-cbind(df,change_data)

#Booking Agency������ ��Ÿ���� ���� ������.
change_data2$BookingAgency1<-ifelse(is.na(change_data2$BookingAgency1)==T,"",as.character(change_data2$BookingAgency1))
change_data2$BookingAgency2<-ifelse(is.na(change_data2$BookingAgency2)==T,"",as.character(change_data2$BookingAgency2))
change_data2$BookingAgency3<-ifelse(is.na(change_data2$BookingAgency3)==T,"",as.character(change_data2$BookingAgency3))
change_data2$BookingAgency4<-ifelse(is.na(change_data2$BookingAgency4)==T,"",as.character(change_data2$BookingAgency4))
change_data2$BookingAgency5<-ifelse(is.na(change_data2$BookingAgency5)==T,"",as.character(change_data2$BookingAgency5))

attach(change_data2)
change_data2$agencynum<-ifelse(BookingAgency5!="",5,
                               ifelse(BookingAgency4!="",4,
                                      ifelse(BookingAgency3!="",3,
                                             ifelse(BookingAgency2!="",2,1))))
change_data2$FirstFlightDep<-as.character(FirstFlightDep)

#����Ƚ���� ��Ÿ���� ���� ������.
change_data2$viaNum<-ifelse(change_data2$Airports3=="",0,
                            ifelse(change_data2$Airports5=="",1,
                                   ifelse(change_data2$Airports7=="",2,3)))

str(change_data2$viaNum)


detach(change_data2)

####�ð��� �и����� ����!

#First�� ��� �װ��Ⱑ �� ������ second���ʹ� ����. �׸��� ������ substró���ϸ�
#����� ���� �ʾ� unlist�� �ȵǴ� �������� �߰�. 
#�׷��� ��¥ �����͸� ����־���!
#FirstFlightDep
split_firstFlightDep<-str_split(substr(change_data2$FirstFlightDep,4,8),":",n=2)
df<-data.frame(matrix(unlist(split_firstFlightDep),nrow=20576,byrow=T))
names(df)<-c("firstFlightDep_hr","firstFlightDep_min")
change_data2<-cbind(df,change_data2)
change_data2$firstFlightDep_hr<-as.integer(change_data2$firstFlightDep_hr)
change_data2$FirstFlightDep_hr_f<-ifelse(substr(change_data2$FirstFlightDep,1,2)=="����",(change_data2$firstFlightDep_hr)+12,change_data2$firstFlightDep_hr)

#FirstFlightArr
split_firstFlightArr<-str_split(substr(change_data2$FirstFlightArr,4,8),":",n=2)
df<-data.frame(matrix(unlist(split_firstFlightArr),nrow=20576,byrow=T))
names(df)<-c("firstFlightArr_hr","firstFlightArr_min")
change_data2<-cbind(df,change_data2)
change_data2$firstFlightArr_hr<-as.integer(change_data2$firstFlightArr_hr)
change_data2$FirstFlightArr_hr_f<-ifelse(substr(change_data2$FirstFlightArr,1,2)=="����",(change_data2$firstFlightArr_hr)+12,change_data2$firstFlightArr_hr)

#SecondFlightDep
change_data2$SecondFlightDep2<-ifelse(change_data2$SecondFlightDep=="","���� 00:00",as.character(change_data2$SecondFlightDep))
split_SecondFlightDep<-str_split(substr(change_data2$SecondFlightDep2,4,8),":",n=2)
df<-data.frame(matrix(unlist(split_SecondFlightDep),nrow=20576,byrow=T))
names(df)<-c("secondFlightDep_hr","secondFlightDep_min")
change_data2<-cbind(df,change_data2)
change_data2$secondFlightDep_hr<-as.integer(as.character(change_data2$secondFlightDep_hr))
change_data2$secondFlightDep_hr_f<-ifelse(substr(change_data2$SecondFlightDep2,1,2)=="����",(change_data2$secondFlightDep_hr)+12,change_data2$secondFlightDep_hr)


#SecondFlightArr
change_data2$SecondFlightArr2<-ifelse(change_data2$SecondFlightArr=="","���� 00:00",as.character(change_data2$SecondFlightArr))
split_SecondFlightArr<-str_split(substr(change_data2$SecondFlightArr2,4,8),":",n=2)
df<-data.frame(matrix(unlist(split_SecondFlightArr),nrow=20576,byrow=T))
names(df)<-c("secondFlightArr_hr","secondFlightArr_min")
change_data2<-cbind(df,change_data2)
change_data2$secondFlightArr_hr<-as.integer(as.character(change_data2$secondFlightArr_hr))
change_data2$secondFlightArr_hr_f<-ifelse(substr(change_data2$SecondFlightArr2,1,2)=="����",(change_data2$secondFlightArr_hr)+12,change_data2$secondFlightArr_hr)


#ThirdFlightDep
change_data2$ThirdFlightDep2<-ifelse(change_data2$ThirdFlightDep=="","���� 00:00",as.character(change_data2$ThirdFlightDep))
split_ThirdFlightDep<-str_split(substr(change_data2$ThirdFlightDep2,4,8),":",n=2)
df<-data.frame(matrix(unlist(split_ThirdFlightDep),nrow=20576,byrow=T))
names(df)<-c("thirdFlightDep_hr","thirdFlightDep_min")
change_data2<-cbind(df,change_data2)
change_data2$thirdFlightDep_hr<-as.integer(as.character(change_data2$thirdFlightDep_hr))
change_data2$thirdFlightDep_hr_f<-ifelse(substr(change_data2$ThirdFlightDep2,1,2)=="����",(change_data2$thirdFlightDep_hr)+12,change_data2$thirdFlightDep_hr)


#ThirdFlightArr
change_data2$ThirdFlightArr2<-ifelse(change_data2$ThirdFlightArr=="","���� 00:00",as.character(change_data2$ThirdFlightArr))
split_ThirdFlightArr<-str_split(substr(change_data2$ThirdFlightArr2,4,8),":",n=2)
df<-data.frame(matrix(unlist(split_ThirdFlightArr),nrow=20576,byrow=T))
names(df)<-c("thirdFlightArr_hr","thirdFlightArr_min")
change_data2<-cbind(df,change_data2)
change_data2$thirdFlightArr_hr<-as.integer(as.character(change_data2$thirdFlightArr_hr))
change_data2$thirdFlightArr_hr_f<-ifelse(substr(change_data2$ThirdFlightArr2,1,2)=="����",(change_data2$thirdFlightArr_hr)+12,change_data2$thirdFlightArr_hr)

#FourthFlightDep
change_data2$FourthFlightDep2<-ifelse(change_data2$FourthFlightDep=="","���� 00:00",as.character(change_data2$FourthFlightDep))
split_FourthFlightDep<-str_split(substr(change_data2$FourthFlightDep2,4,8),":",n=2)
df<-data.frame(matrix(unlist(split_FourthFlightDep),nrow=20576,byrow=T))
names(df)<-c("fourthFlightDep_hr","fourthFlightDep_min")
change_data2<-cbind(df,change_data2)
change_data2$fourthFlightDep_hr<-as.integer(as.character(change_data2$fourthFlightDep_hr))
change_data2$fourthFlightDep_hr_f<-ifelse(substr(change_data2$FourthFlightDep2,1,2)=="����",(change_data2$fourthFlightDep_hr)+12,change_data2$fourthFlightDep_hr)

#FourthFlightArr
change_data2$FourthFlightArr2<-ifelse(change_data2$FourthFlightArr=="","���� 00:00",as.character(change_data2$FourthFlightArr))
split_FourthFlightArr<-str_split(substr(change_data2$FourthFlightArr2,4,8),":",n=2)
df<-data.frame(matrix(unlist(split_FourthFlightArr),nrow=20576,byrow=T))
names(df)<-c("fourthFlightArr_hr","fourthFlightArr_min")
change_data2<-cbind(df,change_data2)
change_data2$fourthFlightArr_hr<-as.integer(as.character(change_data2$fourthFlightArr_hr))
change_data2$fourthFlightArr_hr_f<-ifelse(substr(change_data2$FourthFlightArr2,1,2)=="����",(change_data2$fourthFlightArr_hr)+12,change_data2$fourthFlightArr_hr)


change_data3<-change_data2
library(stringr)


####Moving Time, Stay Time�� ������ �ٲپ� ����
#Moving Time1
change_data3$MovingTime1.1<-ifelse(change_data3$MovingTime1=="","0�ð� 0��",
                                   ifelse(grepl("�ð�",change_data3$MovingTime1)==F,plaste("00�ð�",change_data3MovingTime1),as.character(change_data3$MovingTime1)))
split_MovingTime1<-str_split(change_data3$MovingTime1.1,"�ð�",n=2)
df<-data.frame(matrix(unlist(split_MovingTime1),nrow=20576,byrow=T))
names(df)<-c("MovingTime1_hr","MovingTime1_min")
df$MovingTime1_min<-gsub("��","",df$MovingTime1_min)
df$MovingTime1_hr<-as.integer(as.character(df$MovingTime1_hr))
df$MovingTime1_min<-as.integer(as.character(df$MovingTime1_min))
df$MovingTime1_total<-(df$MovingTime1_hr*60+df$MovingTime1_min)
change_data3<-cbind(df,change_data3)

#MovingTime2
change_data3$MovingTime2.1<-ifelse(change_data3$MovingTime2=="","0�ð� 0��",
                                   ifelse(grepl("�ð�",change_data3$MovingTime2)==F,paste("00�ð�",change_data3$MovingTime2),as.character(change_data3$MovingTime2)))
split_MovingTime2<-str_split(change_data3$MovingTime2.1,"�ð�",n=2)
df<-data.frame(matrix(unlist(split_MovingTime2),nrow=20576,byrow=T))
names(df)<-c("MovingTime2_hr","MovingTime2_min")
df$MovingTime2_min<-gsub("��","",df$MovingTime2_min)
df$MovingTime2_hr<-as.integer(as.character(df$MovingTime2_hr))
df$MovingTime2_min<-as.integer(as.character(df$MovingTime2_min))
df$MovingTime2_total<-(df$MovingTime2_hr*60+df$MovingTime2_min)
change_data3<-cbind(df,change_data3)

#MovingTime3
change_data3$MovingTime3.1<-ifelse(change_data3$MovingTime3=="","0�ð� 0��",
                                 ifelse(grepl("�ð�",change_data3$MovingTime3)==F,paste("00�ð�",change_data3$MovingTime3),as.character(change_data3$MovingTime3)))
split_MovingTime3<-str_split(change_data3$MovingTime3.1,"�ð�",n=2)
df<-data.frame(matrix(unlist(split_MovingTime3),nrow=20576,byrow=T))
names(df)<-c("MovingTime3_hr","MovingTime3_min")
df$MovingTime3_min<-gsub("��","",df$MovingTime3_min)
df$MovingTime3_hr<-as.integer(as.character(df$MovingTime3_hr))
df$MovingTime3_min<-as.integer(as.character(df$MovingTime3_min))
df$MovingTime3_total<-(df$MovingTime3_hr*60+df$MovingTime3_min)
change_data3<-cbind(df,change_data3)

#MovingTime4
change_data3$MovingTime4.1<-ifelse(change_data3$MovingTime4=="","0�ð� 0��",
                                   ifelse(grepl("�ð�",change_data3$MovingTime4)==F,paste("00�ð�",change_data3$MovingTime4),as.character(change_data3$MovingTime4)))
split_MovingTime4<-str_split(change_data3$MovingTime4.1,"�ð�",n=2)
df<-data.frame(matrix(unlist(split_MovingTime4),nrow=20576,byrow=T))
names(df)<-c("MovingTime4_hr","MovingTime4_min")
df$MovingTime4_min<-gsub("��","",df$MovingTime4_min)
df$MovingTime4_hr<-as.integer(as.character(df$MovingTime4_hr))
df$MovingTime4_min<-as.integer(as.character(df$MovingTime4_min))
df$MovingTime4_total<-(df$MovingTime4_hr*60+df$MovingTime4_min)
change_data3<-cbind(df,change_data3)


#StayTime1
change_data3$StayTime1.1<-ifelse(change_data3$Staytime=="","0�ð� 0��",
                                 ifelse(grepl("�ð�",change_data3$Staytime)==F,paste("00�ð�",change_data3$Staytime),as.character(change_data3$Staytime)))
split_StayTime1<-str_split(change_data3$StayTime1.1,"�ð�",n=2)
df<-data.frame(matrix(unlist(split_StayTime1),nrow=20576,byrow=T))
names(df)<-c("StayTime1_hr","StayTime1_min")
df$StayTime1_min<-gsub("��","",df$StayTime1_min)
df$StayTime1_hr<-as.integer(as.character(df$StayTime1_hr))
df$StayTime1_min<-as.integer(as.character(df$StayTime1_min))
df$StayTime1_total<-(df$StayTime1_hr*60+df$StayTime1_min)
change_data3<-cbind(df,change_data3)

#StayTime2
change_data3$StayTime2.1<-ifelse(change_data3$Staytime2=="","0�ð� 0��",
                                 ifelse(grepl("�ð�",change_data3$Staytime2)==F,paste("00�ð�",change_data3$Staytime2),as.character(change_data3$Staytime2)))
split_StayTime2<-str_split(change_data3$StayTime2.1,"�ð�",n=2)
df<-data.frame(matrix(unlist(split_StayTime2),nrow=20576,byrow=T))
names(df)<-c("StayTime2_hr","StayTime2_min")
df$StayTime2_min<-gsub("��","",df$StayTime2_min)
df$StayTime2_hr<-as.integer(as.character(df$StayTime2_hr))
df$StayTime2_min<-as.integer(as.character(df$StayTime2_min))
df$StayTime2_total<-(df$StayTime2_hr*60+df$StayTime2_min)
change_data3<-cbind(df,change_data3)

#StayTime3
change_data3$StayTime3.1<-ifelse(change_data3$Staytime3=="","0�ð� 0��",
                                 ifelse(grepl("�ð�",change_data3$Staytime3)==F,paste("00�ð�",change_data3$Staytime3),as.character(change_data3$Staytime3)))
split_StayTime3<-str_split(change_data3$StayTime3.1,"�ð�",n=2)
df<-data.frame(matrix(unlist(split_StayTime3),nrow=20576,byrow=T))
names(df)<-c("StayTime3_hr","StayTime3_min")
df$StayTime3_min<-gsub("��","",df$StayTime3_min)
df$StayTime3_hr<-as.integer(as.character(df$StayTime3_hr))
df$StayTime3_min<-as.integer(as.character(df$StayTime3_min))
df$StayTime3_total<-(df$StayTime3_hr*60+df$StayTime3_min)
change_data3<-cbind(df,change_data3)


change_data4<-change_data3


final_total_data<-subset(change_data3,select=c(Year, Month,Date_num,BookingAgency1, agencynum, BookingPrice1,BookingPrice2,
                                               BookingPrice3,BookingPrice4,BookingPrice5,Airports2,Airports4,Airports6,Airports8, 
                                               Staylocation, Staylocation2, Staylocation3, viaNum, StayTime1_total, StayTime2_total,StayTime3_total,  
                                               MovingTime1_total, MovingTime2_total,MovingTime3_total,MovingTime4_total,FirstFlightDep_hr_f,
                                               FirstFlightArr_hr_f,secondFlightDep_hr_f,secondFlightArr_hr_f,thirdFlightDep_hr_f,
                                               thirdFlightArr_hr_f,fourthFlightDep_hr_f,fourthFlightArr_hr_f, Facility))


final_via0_data<-subset(final_total_data,subset=viaNum==0,select=c(Year,Month,Date_num,BookingAgency1,agencynum,BookingPrice1,BookingPrice2,BookingPrice3,
                                                                   BookingPrice4,BookingPrice5,Airports2,MovingTime1_total,FirstFlightDep_hr_f,
                                                                   FirstFlightArr_hr_f,Facility))
final_via1_data<-subset(final_total_data,subset=viaNum==1,select=c(Year,Month,Date_num,BookingAgency1,agencynum,BookingPrice1,BookingPrice2,BookingPrice3,
                                                                   BookingPrice4,BookingPrice5,Airports2,Airports4,StayTime1_total,Staylocation,MovingTime1_total,
                                                                   MovingTime2_total,FirstFlightDep_hr_f,FirstFlightArr_hr_f,secondFlightDep_hr_f,
                                                                   secondFlightArr_hr_f,Facility))
                                                                   
                                                                   
final_via2_data<-subset(final_total_data,subset=viaNum==2,select=c(Year,Month,Date_num,BookingAgency1,agencynum,BookingPrice1,BookingPrice2,BookingPrice3,
                                                                   BookingPrice4,BookingPrice5,Airports2,Airports4,Airports6,StayTime1_total,StayTime2_total,
                                                                   Staylocation,Staylocation2,MovingTime1_total,MovingTime2_total,MovingTime3_total,FirstFlightDep_hr_f,FirstFlightArr_hr_f,
                                                                   secondFlightDep_hr_f,secondFlightArr_hr_f,thirdFlightDep_hr_f,thirdFlightArr_hr_f,
                                                                   Facility))
                                                                   
                                                                   
                                                                  

final_via3_data<-subset(final_total_data,subset=viaNum==3,select=c(Year, Month,Date_num,BookingAgency1, agencynum, BookingPrice1,BookingPrice2,
                                                                   BookingPrice3,BookingPrice4,BookingPrice5,Airports2,Airports4,Airports6,Airports8, 
                                                                   Staylocation, Staylocation2, Staylocation3, StayTime1_total, StayTime2_total,StayTime3_total,  
                                                                   MovingTime1_total, MovingTime2_total,MovingTime3_total,MovingTime4_total,FirstFlightDep_hr_f,
                                                                   FirstFlightArr_hr_f,secondFlightDep_hr_f,secondFlightArr_hr_f,thirdFlightDep_hr_f,
                                                                   thirdFlightArr_hr_f,fourthFlightDep_hr_f,fourthFlightArr_hr_f, Facility))

write.csv(final_total_data,file="C:/Users/Jungwoo Lim/Documents/2018�� ����/PSAT/�����/Data2/final_total_data.csv")
write.csv(final_via0_data,file="C:/Users/Jungwoo Lim/Documents/2018�� ����/PSAT/�����/Data2/final_via0_data.csv")
write.csv(final_via1_data,file="C:/Users/Jungwoo Lim/Documents/2018�� ����/PSAT/�����/Data2/final_via1_data.csv")
write.csv(final_via2_data,file="C:/Users/Jungwoo Lim/Documents/2018�� ����/PSAT/�����/Data2/final_via2_data.csv")
write.csv(final_via3_data,file="C:/Users/Jungwoo Lim/Documents/2018�� ����/PSAT/�����/Data2/final_via3_data.csv")

getwd()



